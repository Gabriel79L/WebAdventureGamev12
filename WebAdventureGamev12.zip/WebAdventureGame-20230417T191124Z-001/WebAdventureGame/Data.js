let Data = function(ident,name, strength,dexterity,intelligence,wisdom,charisma, playerRace, playerClass) {
    this.ident = ident;
    this.name = name;
    this.strength = strength;
    this.dexterity = dexterity;
    this.intelligence = intelligence;
    this.wisdom = wisdom;
    this.charisma = charisma;
    this.playerRace = playerRace;
    this.playerClass = playerClass;
}

module.exports = Data;